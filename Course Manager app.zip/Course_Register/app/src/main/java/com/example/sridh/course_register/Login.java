package com.example.sridh.course_register;

import android.content.Context;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import io.realm.Realm;

public class Login extends Fragment {
    Boolean signUp = false;
    Boolean successfullLogin = false;
    Realm realm;
    String userName,Password;
    private OnFragmentInteractionListener mListener;

    public Login() {
        // Required empty public constructor
    }

    public void onResume(){
        super.onResume();

        // Set title bar
        ((MainActivity) getActivity())
                .setActionBarTitle("Course Manager");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login,container, false);
        if(successfullLogin){
            if((!(userName.trim().isEmpty())) && (!(Password.trim().isEmpty()))){
                signUp = false;
                mListener.onFragmentInteraction(signUp,successfullLogin, userName, Password);
            }
        }
        view.findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUp = true;
                successfullLogin = false;
                userName = "";
                Password = "";
                mListener.onFragmentInteraction(signUp,successfullLogin,userName,Password);
            }
        });
        view.findViewById(R.id.buttonLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText) getActivity().findViewById(R.id.username);
                EditText password = (EditText) getActivity().findViewById(R.id.password);
                if(username.getText().toString().trim().isEmpty() || password.getText().toString().trim().isEmpty()){
                    Toast.makeText(getActivity(),"Username or Password cannot be empty",Toast.LENGTH_SHORT).show();
                } else {
                    realm.init(getActivity());
                    realm=realm.getDefaultInstance();
                    UserList value = realm.where(UserList.class).equalTo("username",username.getText().toString().trim()).findFirst();
                    if(value == null){
                        Toast.makeText(getActivity(),"username does not exit. Please enter correct username",Toast.LENGTH_SHORT).show();
                    } else if(!(value.getPassword().trim().equals(password.getText().toString().trim()))){
                        Toast.makeText(getActivity(),"Password is incorrect",Toast.LENGTH_SHORT).show();
                    } else {
                        //getFragmentManager().popBackStack();
                        signUp = false;
                        successfullLogin = true;
                        userName = username.getText().toString().trim();
                        Password = password.getText().toString().trim();
                        Log.d("calling Main activity","Check");
                        mListener.onFragmentInteraction(signUp,successfullLogin, userName, Password);
                    }
                }
            }
        });
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity) {
            mListener = (OnFragmentInteractionListener) context;

        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Boolean signUp,Boolean successfullLogin,String userName, String Passsword);
    }

}
