package com.example.sridh.course_register;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import io.realm.RealmResults;

/**
 * Created by sridh on 11/3/2017.
 */

public class InstructorListAdaptor extends RecyclerView.Adapter<InstructorListAdaptor.ViewHolder> {
    Context courseCreation;
    ArrayList<Instructors> instructors;
    String instructor_selected_first;
    String instructor_selected_last;
    String instructor_photo;
    CourseCreation creation;
    int selected;
    int list_instructor;

    public InstructorListAdaptor(Context courseCreation, int list_instructor, ArrayList<Instructors> instructors, CourseCreation creation) {
        this.creation = creation;
        this.courseCreation = courseCreation;
        this.instructors = instructors;
        this.list_instructor = list_instructor;
        selected = instructors.size();
        Log.d("demo12",instructors.toString());
    }

    View view;
    @Override
    public InstructorListAdaptor.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_instructor, parent, false);
        InstructorListAdaptor.ViewHolder viewHolder=new InstructorListAdaptor.ViewHolder(view);

        return viewHolder;
    }


    @Override
    public void onBindViewHolder(InstructorListAdaptor.ViewHolder holder, int position) {
        if(!(instructors.get(position).getInstructor_image().trim().isEmpty())){
            Uri uri = Uri.fromFile(new File(instructors.get(position).getInstructor_image().trim()));
            if(uri != null){
                holder.default_image.setImageURI(uri);
            }

//            try {
//                File f=new File(instructors.get(position).getInstructor_image().trim(), instructors.get(position).getInstructor_firstname().trim()+instructors.get(position).getInstrctor_lastname().trim()+".jpg");
//                Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
//                if(b != null){
//                    holder.default_image.setImageBitmap(b);
//                } else {
//                    Uri uri = Uri.fromFile(new File(instructors.get(position).getInstructor_image().trim()));
//                    if(uri != null){
//                        holder.default_image.setImageURI(uri);
//                    }
//                }
//            }
//            catch (FileNotFoundException e)
//            {
//                e.printStackTrace();
//            }
        }
        holder.instructors = instructors;
        holder.context = courseCreation;
        holder.creation = creation;
        holder.position = position;
        if(selected == position){
            holder.selection.setImageDrawable(courseCreation.getDrawable(android.R.drawable.radiobutton_on_background));
        } else {
            holder.selection.setImageDrawable(courseCreation.getDrawable(android.R.drawable.radiobutton_off_background));
        }
        holder.instructor_name.setText(instructors.get(position).getInstructor_firstname().trim()+" "+instructors.get(position).getInstrctor_lastname().trim());
        Log.d("demo11",instructors.toString());


    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        if(instructors == null){
            return 0;
        } else {
            return instructors.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView default_image;
        public TextView instructor_name;
        public ImageView selection;
        Context context;
        CourseCreation creation;
        int position;
        ArrayList<Instructors> instructors;
        public ViewHolder(View itemView) {
            super(itemView);
            default_image = (ImageView) itemView.findViewById(R.id.instructor_photo);
            instructor_name = (TextView) itemView.findViewById(R.id.instructor_name);
            selection = (ImageView) itemView.findViewById(R.id.select);
            selection.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selected = position;
                    instructor_selected_first = instructors.get(position).getInstructor_firstname().trim();
                    instructor_selected_last  = instructors.get(position).getInstrctor_lastname().trim();
                    instructor_photo = instructors.get(position).getInstructor_image();
                    selection.setImageDrawable(courseCreation.getDrawable(android.R.drawable.radiobutton_on_background));
                    InstructorListAdaptor.this.notifyDataSetChanged();
                    //mListener = (selectInstructor) context;
                    creation.selectedInstrctor(instructor_selected_first,instructor_selected_last,instructor_photo);
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    return false;
                }
            });

        }
    }
}
