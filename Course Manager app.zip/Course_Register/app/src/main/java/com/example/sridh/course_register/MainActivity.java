package com.example.sridh.course_register;

import android.app.FragmentManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements CourseDisplay.OnFragmentInteractionListener,Login.OnFragmentInteractionListener,Instructor_Display.OnFragmentInteractionListener,Register.OnFragmentInteractionListener,Add_instructor.OnFragmentInteractionListener,CourseCreation.OnFragmentInteractionListener{
    Boolean signUp = false;
    Boolean successfullLogin = false;
    String userName,Password;
    Login login = new Login();
    Register register = new Register();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar actions = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(actions);
        getFragmentManager().beginTransaction()
                .add(R.id.mainActivity, login,"first")
                .commit();
    }
    public void setActionBarTitle(String title) {
        getSupportActionBar().setTitle(title);
    }


    @Override
    public void onFragmentInteraction(Boolean signUp, Boolean successfullLogin, String userName, String Passsword) {
        this.userName = userName;
        this.Password = Passsword;
        this.signUp = signUp;
        this.successfullLogin = successfullLogin;
        if (signUp){
            getFragmentManager().beginTransaction()
                    .replace(R.id.mainActivity,register,"second")
                    .commit();
        }
        else if(successfullLogin){
            CourseWork courseWork = new CourseWork();
            courseWork.setUserName(userName);
            getFragmentManager().beginTransaction()
                    .replace(R.id.mainActivity,courseWork,"third")
                    .commit();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) { switch(item.getItemId()) {
        case R.id.home:
            //add the function to perform here
            if(successfullLogin){
                CourseWork courseWork = new CourseWork();
                courseWork.setUserName(userName);
                getFragmentManager().beginTransaction()
                        .replace(R.id.mainActivity,courseWork,"third")
                        .commit();
                getSupportActionBar().setTitle("Course Manager");
               // getFragmentManager().popBackStack();
            } else {
                Toast.makeText(getBaseContext(),"Please login to add instructor",Toast.LENGTH_SHORT).show();
            }
            return(true);
        case R.id.instructors:
            //add the function to perform here
            if(successfullLogin){
                Instructor_Display instructor_display = new Instructor_Display();
                instructor_display.setUsername(userName);
                getFragmentManager().beginTransaction()
                        .replace(R.id.mainActivity, instructor_display,"five").addToBackStack(null)
                        .commit();
                getSupportActionBar().setTitle("Instructors");
            } else {
                Toast.makeText(getBaseContext(),"Please login to view instructors",Toast.LENGTH_SHORT).show();
            }
            return(true);
        case R.id.addinstructor:
            if(successfullLogin){
                Add_instructor Add_instructor = new Add_instructor();
                Add_instructor.setUserName(userName);
                getFragmentManager().beginTransaction()
                        .replace(R.id.mainActivity, Add_instructor,"four").addToBackStack(null)
                        .commit();
                getSupportActionBar().setTitle("Add Instructor");
            } else {
                Toast.makeText(getBaseContext(),"Please login to add instructor",Toast.LENGTH_SHORT).show();
            }
            return(true);
        case R.id.logout:
            //add the function to perform here
            if(successfullLogin){
                successfullLogin=false;
                Log.d("successfil",successfullLogin.toString());
                getFragmentManager().beginTransaction().remove(getFragmentManager().findFragmentById(R.id.mainActivity)).commit();
                getFragmentManager().popBackStack();
//                getFragmentManager().popBackStack();
                Login login=new Login();
                getFragmentManager().beginTransaction()
                        .replace(R.id.mainActivity, login,"four")
                        .commit();
            } else {
                Toast.makeText(getBaseContext(),"Already Logged Out",Toast.LENGTH_SHORT).show();
            }
            return(true);
        case R.id.exit:
            //add the function to perform here
            finish();
    }
        return(super.onOptionsItemSelected(item));
    }

    /**
     * Take care of popping the fragment back stack or finishing the activity
     * as appropriate.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void SaveValues(Boolean signUp, Boolean successfullLogin, String userName, String Passsword) {
        this.successfullLogin = successfullLogin;
        this.signUp = signUp;
        this.userName = userName;
        this.Password = Passsword;

        CourseWork courseWork = new CourseWork();
        courseWork.setUserName(userName);
        getFragmentManager().beginTransaction()
                .replace(R.id.mainActivity,courseWork,"third")
                .commit();
    }
//
//    @Override
//    public void courseregister() {
//
//    }

    @Override
    public void SaveInstructor() {
        getFragmentManager().popBackStack();
    }

    @Override
    public void courseregister() {

    }

    @Override
    public void Instructor_List() {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
