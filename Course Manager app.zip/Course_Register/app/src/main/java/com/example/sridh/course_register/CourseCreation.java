package com.example.sridh.course_register;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.IdRes;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import io.realm.Realm;
import io.realm.RealmResults;

public class CourseCreation extends Fragment {
    Realm realm;
    ArrayList<String> day = new ArrayList<String>(Arrays.asList("Select","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"));
    ArrayList<String> time = new ArrayList<String>(Arrays.asList("AM","PM"));
    ArrayList<String> semesterValue = new ArrayList<String>(Arrays.asList("Select Semester","Spring","Fall","Summer "));
    String daySelected = "";
    String classHourSelected = "";
    String timeSelected = "AM";
    String semesterSelected = "";
    String hoursEntered = "";
    String minEntered = "";
    String instructor_selected_first;
    String instructor_selected_last;
    String instructor_photo;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    RecyclerView mRecyclerView;
    ArrayList<Instructors> instructor = new ArrayList<Instructors>();

    private CourseCreation.OnFragmentInteractionListener mListener;
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    String username;
    public CourseCreation() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_course_work,container, false);

        final Spinner daySpinner = (Spinner) view.findViewById(R.id.day);
        ArrayAdapter<String> dayAdaptor = new ArrayAdapter<String>(view.getContext(),android.R.layout.simple_spinner_item,day);
        dayAdaptor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        daySpinner.setAdapter(dayAdaptor);
        daySpinner.setPrompt("Select one");

        Button reset=view.findViewById(R.id.reset);

        daySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i> 0){
                    daySelected = adapterView.getItemAtPosition(i).toString().trim();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        final Spinner timeSpinner = (Spinner) view.findViewById(R.id.time);

        ArrayAdapter<String> timeAdaptor = new ArrayAdapter<String>(view.getContext(),android.R.layout.simple_spinner_item,time);
        timeAdaptor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeSpinner.setPrompt("AM");
        timeSpinner.setAdapter(timeAdaptor);
        timeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                timeSelected = adapterView.getItemAtPosition(i).toString().trim();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

         final Spinner semester = (Spinner) view.findViewById(R.id.semester);
        ArrayAdapter<String> semesterAdaptor = new ArrayAdapter<String>(view.getContext(),android.R.layout.simple_spinner_item,semesterValue);
        semesterAdaptor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        semester.setPrompt("Select one");
        semester.setAdapter(semesterAdaptor);
        semester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i > 0){
                    semesterSelected = adapterView.getItemAtPosition(i).toString().trim();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        realm = Realm.getDefaultInstance();
        RealmResults<Instructors> instructorsList = realm
                .where(Instructors.class)
                .equalTo("username3",username.trim())
                .findAll();
        if(instructor != null){
            instructor.clear();
        }
        if(instructorsList != null){
            for(int x =0;x<instructorsList.size();x++){
                instructor.add(instructorsList.get(x));
            }
        }
        mRecyclerView = (RecyclerView) view.findViewById(R.id.instructorList);
        Log.d("demo",instructor.toString());
        if((instructor == null) || (instructor.size() == 0)){
            TextView emptyText = (TextView) view.findViewById(R.id.emptyText);
            emptyText.setVisibility(View.VISIBLE);
            emptyText.setText("You haven’t added any instructor yet, please add at least one" +
                    "instructor to continue");
            mRecyclerView.setVisibility(View.GONE);
            Log.d("demo14",instructor.toString());
            view.findViewById(R.id.create).setEnabled(false);
        } else {
            //mRecyclerView.setHasFixedSize(true);

            // use a linear layout managerq
            mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL,false);
            mRecyclerView.setLayoutManager(mLayoutManager);

            // specify an adapter (see also next example)
            mAdapter = new InstructorListAdaptor(getActivity(), R.layout.list_instructor, instructor,CourseCreation.this);
            Log.d("demo13",instructor.toString());
            mRecyclerView.setAdapter(mAdapter);
        }

        final RadioGroup rg = (RadioGroup) view.findViewById(R.id.classHours);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                if( i == R.id.one){
                    classHourSelected = "1";
                } else if(i == R.id.two){
                    classHourSelected = "2";
                } else if( i == R.id.three){
                    classHourSelected = "3";
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());

                // set title
                alertDialogBuilder.setTitle("Reset");

                // set dialog message
                alertDialogBuilder
                        .setMessage("Are you sure ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                EditText hours = (EditText) getActivity().findViewById(R.id.hour);

                                EditText  min = (EditText) getActivity().findViewById(R.id.min);

                                EditText  courseTitle = (EditText) getActivity().findViewById(R.id.courseTitle);

                                courseTitle.setText("");
                                hours.setText("");
                                min.setText("");

                                 daySelected = "";
                                 classHourSelected = "";
                                 timeSelected = "AM";
                                 semesterSelected = "";
                                 hoursEntered = "";
                                 minEntered = "";
                                 instructor_selected_first="";
                                 instructor_selected_last="";
                                 instructor_photo="";

                                mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL,false);
                                mRecyclerView.setLayoutManager(mLayoutManager);

                                // specify an adapter (see also next example)
                                mAdapter = new InstructorListAdaptor(getActivity(), R.layout.list_instructor, instructor,CourseCreation.this);
                                Log.d("demo13",instructor.toString());
                                mRecyclerView.setAdapter(mAdapter);

                                rg.clearCheck();
                               daySpinner.setSelection(0);
                               timeSpinner.setSelection(0);
                               semester.setSelection(0);


                            }
                        })
                        .setNegativeButton("No",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
            }
        });
        view.findViewById(R.id.create).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText hours = (EditText) getActivity().findViewById(R.id.hour);
                hoursEntered = hours.getText().toString().trim();
                EditText  min = (EditText) getActivity().findViewById(R.id.min);
                minEntered = min.getText().toString().trim();
                EditText  courseTitle = (EditText) getActivity().findViewById(R.id.courseTitle);
                String title = courseTitle.getText().toString().trim();

                Log.d("semester",semesterSelected);
                if((title != null) && (hoursEntered != null) && (minEntered != null) && (classHourSelected != null) && (daySelected != "") && (semesterSelected != "") && (timeSelected != "") &&(instructor_selected_first != null) && (instructor_selected_last != null)){
                    realm.init(getActivity());
                    realm=realm.getDefaultInstance();
                    Courses value = realm.where(Courses.class)
                            .equalTo("courseTitle",title)
                            .equalTo("username2",username)
                            .findFirst();
                    if(value != null) {
                        Toast.makeText(getActivity(),"Course Title already exists",Toast.LENGTH_SHORT).show();
                    } else {
                        if((Integer.parseInt(hoursEntered)  > 0) && (Integer.parseInt(hoursEntered)  < 13) ){
                            if((Integer.parseInt(minEntered)  >= 0) && (Integer.parseInt(minEntered)  < 60) ){
                                realm.beginTransaction();

                                Courses courses = realm.createObject(Courses.class,title.trim());
                                courses.setHour(hoursEntered.trim());
                                courses.setInstrctor_lastname(instructor_selected_last.trim());
                                courses.setInstructor_firstname(instructor_selected_first.trim());
                                courses.setDay(daySelected.trim());
                                courses.setMin(minEntered.trim());
                                courses.setMorning_type(timeSelected.trim());
                                courses.setUsername2(username.trim());
                                courses.setCredit_hour(classHourSelected.trim());
                                courses.setInstructor_Image(instructor_photo.trim());
                                courses.setSemster(semesterSelected.trim());
                                realm.commitTransaction();
                                Log.d("demo", courses.toString());
                                getFragmentManager().popBackStack();
                            } else {
                                Toast.makeText(getActivity(),"Invalid min entered",Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(),"Invalid hours entered",Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(getActivity(),"Please add all details to create course",Toast.LENGTH_SHORT).show();
                }


            }
        });
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public void selectedInstrctor(String instructor_selected_first, String instructor_selected_last, String instructor_photo) {
        this.instructor_selected_first = instructor_selected_first;
        this.instructor_selected_last = instructor_selected_last;
        this.instructor_photo = instructor_photo;
    }

    public interface OnFragmentInteractionListener {
        void courseregister();
    }

    public void onResume(){
        super.onResume();

        // Set title bar
        Log.d("demo","on resume");
        ((MainActivity) getActivity())
                .setActionBarTitle("Create Course");

    }
}
