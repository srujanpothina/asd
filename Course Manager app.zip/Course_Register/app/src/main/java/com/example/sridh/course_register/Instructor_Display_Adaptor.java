package com.example.sridh.course_register;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;

public class Instructor_Display_Adaptor extends RecyclerView.Adapter<Instructor_Display_Adaptor.ViewHolder> {
    Context activity;
    ArrayList<Instructors> instructors;
    int list_instructor_display;
    Realm realm;

    public Instructor_Display_Adaptor(Context activity, int list_instructor_display, ArrayList<Instructors> instructors) {
        if(instructors != null){
            realm=Realm.getDefaultInstance();
            this.activity = activity;
            this.instructors = instructors;
            this.list_instructor_display = list_instructor_display;
        }
    }

    @Override
    public void onBindViewHolder(final Instructor_Display_Adaptor.ViewHolder holder, final int position) {
        if(!(instructors.get(position).getInstructor_image().trim().isEmpty())){
            Uri uri = Uri.fromFile(new File(instructors.get(position).getInstructor_image().trim()));
            if(uri != null){
                holder.default_image.setImageURI(uri);
            }
        }
        holder.instructors = instructors;
        holder.instructor_email.setText(instructors.get(position).getInstructor_email().trim());
        holder.instructor_first_name.setText(instructors.get(position).getInstructor_firstname().trim());
        holder.instructor_last_name.setText(instructors.get(position).getInstrctor_lastname().trim());
        holder.instructor_personal_website.setText(instructors.get(position).getInstructor_website().trim());
        Log.d("path:",instructors.get(position).getInstructor_image().trim());

        view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
               // realm.beginTransaction();
//
                RealmResults<Courses> course=realm.where(Courses.class).equalTo("instructor_firstname",holder.instructors.get(position).getInstructor_firstname()).findAll();
               Log.d("demo",course.toString());
                if(course.size()<=0)
                {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            view.getContext());

                    // set title
                    alertDialogBuilder.setTitle("Delete Instructor");

                    // set dialog message
                    alertDialogBuilder
                            .setMessage("Are you sure ?")
                            .setCancelable(false)
                            .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {

                                    realm.beginTransaction();
//
                                    RealmResults<Instructors> course=realm.where(Instructors.class).equalTo("instructor_email",holder.instructors.get(position).getInstructor_email()).findAll();
                                    course.deleteAllFromRealm();
//
                                    realm.commitTransaction();
//
//
                                    instructors.remove(position);
                                    notifyDataSetChanged();

                                }
                            })
                            .setNegativeButton("No",new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {

                                    dialog.cancel();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();
                }
                else
                {
                    Toast.makeText(activity.getApplicationContext(),"This instructor is associated with course.Canot be deleted",Toast.LENGTH_LONG).show();
                }



                return true;
            }
        });

        //Log.d("demo11",instructors.toString());
    }


    View view;
    @Override
    public Instructor_Display_Adaptor.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_instructor_display, parent, false);
        Instructor_Display_Adaptor.ViewHolder viewHolder=new Instructor_Display_Adaptor.ViewHolder(view);

        return viewHolder;
    }


    @Override
    public int getItemCount() {
        if(instructors == null){
            return 0;
        } else {
            return instructors.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ArrayList<Instructors> instructors;
        public ImageView default_image;
        public TextView instructor_personal_website,instructor_email, instructor_last_name,instructor_first_name;
        public ViewHolder(View itemView) {
            super(itemView);
            default_image = (ImageView) itemView.findViewById(R.id.default_image);
            instructor_personal_website = (TextView) itemView.findViewById(R.id.instructor_personal_website);
            instructor_email =  (TextView) itemView.findViewById(R.id.instructor_email);
            instructor_last_name =  (TextView) itemView.findViewById(R.id.instructor_last_name);
            instructor_first_name =  (TextView) itemView.findViewById(R.id.instructor_first_name);
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    return false;
                }
            });
        }
    }
}
