package com.example.sridh.course_register;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Instructor_Display.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class Instructor_Display extends Fragment {

    private OnFragmentInteractionListener mListener;
    String username;
    Realm realm;
    //    private CourseWork.OnFragmentInteractionListener mListener;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    RecyclerView mRecyclerView;
    ArrayList<Instructors> instructors = new ArrayList<Instructors>();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Instructor_Display() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_instructor__display,container, false);
        realm = Realm.getDefaultInstance();
        RealmResults<Instructors> instructorList = realm
                .where(Instructors.class)
                .equalTo("username3",username.trim())
                .findAll();
        if(instructors != null){
            instructors.clear();
        }
        if(instructorList != null){
            for(int x =0;x<instructorList.size();x++){
                instructors.add(instructorList.get(x));
            }
        }
        mRecyclerView = (RecyclerView) view.findViewById(R.id.instructorList);
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout managerq
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter (see also next example)
        mAdapter = new Instructor_Display_Adaptor(this.getActivity(), R.layout.list_instructor_display, instructors);
        mRecyclerView.setAdapter(mAdapter);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void Instructor_List();
    }
}
