package com.example.sridh.course_register;

import android.app.FragmentManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;


public class CourseWork extends Fragment implements CourseCreation.OnFragmentInteractionListener{
    String userName;
    Realm realm;

    static Courses course;
//    private CourseWork.OnFragmentInteractionListener mListener;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    RecyclerView mRecyclerView;
    ArrayList<Courses> courses = new ArrayList<Courses>();

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public CourseWork() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_course_work2,container, false);

        view.findViewById(R.id.addCourse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFragmentManager().beginTransaction()
                .replace(R.id.mainActivity,new CourseCreation(),"fourth")
                        .commit();
            }
        });
        realm = Realm.getDefaultInstance();
        RealmResults<Courses> courseList = realm
                .where(Courses.class)
                .equalTo("username2",userName.trim())
                .findAll();
        if(courses != null){
            courses.clear();
        }
        if(courseList != null){
            for(int x =0;x<courseList.size();x++){
                courses.add(courseList.get(x));
            }
        }
        mRecyclerView = (RecyclerView) view.findViewById(R.id.courseList);
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout managerq
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter (see also next example)
        mAdapter = new CourseListAdaptor(CourseWork.this, R.layout.list_course, courses);
        mRecyclerView.setAdapter(mAdapter);
        view.findViewById(R.id.addCourse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CourseCreation courseCreation = new CourseCreation();
                courseCreation.setUsername(userName);
                getFragmentManager().beginTransaction()
                        .replace(R.id.mainActivity,courseCreation,"four").addToBackStack(null)
                        .commit();
                ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Create Course");
            }
        });
        return view;

    }
    public void display()
    {
        Log.d("demo",course.toString());
        FragmentManager fragmentManager = getFragmentManager();
        android.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.mainActivity, new CourseDisplay(course), "addinstructor");
        fragmentTransaction.commit();
    }
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }

    @Override
    public void courseregister() {

    }

//    public interface OnFragmentInteractionListener {
//        void courseregister();
//    }

    public void onResume(){
        super.onResume();

        // Set title bar
        ((MainActivity) getActivity())
                .setActionBarTitle("Course Manager");

    }
}
