package com.example.sridh.course_register;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Created by sridh on 11/3/2017.
 */

public class CourseListAdaptor extends RecyclerView.Adapter<CourseListAdaptor.ViewHolder> {
    Context courseCreation;
    CourseWork course;
    ArrayList<Courses> courses;
    int list_course;
    Realm realm;

    public CourseListAdaptor(CourseWork courseCreation, int list_course, ArrayList<Courses> courses) {
        if(courses != null){
            realm=Realm.getDefaultInstance();
            this.course = courseCreation;
            this.courses = courses;

            this.list_course = list_course;
        }
    }

    View view;
    @Override
    public CourseListAdaptor.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_course, parent, false);
        ViewHolder viewHolder=new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final CourseListAdaptor.ViewHolder holder, final int position) {
        holder.title.setText(courses.get(position).getCourseTitle());
        holder.day.setText(courses.get(position).getDay().substring(0,3));
        holder.time.setText(courses.get(position).getMorning_type());
        holder.hour.setText(courses.get(position).getHour());
        holder.min.setText(courses.get(position).getMin());
        holder.courses = courses;
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo",holder.courses.get(position).toString());
                CourseWork.course=holder.courses.get(position);
                course.display();

//

                //course.getFragmentManager().beginTransaction().add(R.id.mainActivity,new CourseDisplay(holder.courses.get(position))).commit();

            }
        });
        view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                       course.getContext());

                // set title
                alertDialogBuilder.setTitle("Delete Course");

                // set dialog message
                alertDialogBuilder
                        .setMessage("Are you sure ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                realm.beginTransaction();
//
                                RealmResults<Courses> course=realm.where(Courses.class).equalTo("username2",holder.courses.get(position).getUsername2()).equalTo("courseTitle",holder.courses.get(position).getCourseTitle()).findAll();
                                course.deleteAllFromRealm();
//
                                realm.commitTransaction();
//
//
                                courses.remove(position);
                                notifyDataSetChanged();

                            }
                        })
                        .setNegativeButton("No",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();


                return true;
            }
        });
        if(!(courses.get(position).getInstructor_Image().trim().isEmpty())){
            Uri uri = Uri.fromFile(new File(courses.get(position).getInstructor_Image().trim()));
            if(uri != null){
                holder.default_image.setImageURI(uri);
            }
        }
        holder.instructor.setText(courses.get(position).getInstructor_firstname()+" "+ courses.get(position).getInstrctor_lastname());
    }

    @Override
    public int getItemCount() {
        if(courses == null){
            return 0;
        } else {
            return courses.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ArrayList<Courses> courses;
        public ImageView default_image;
        public TextView title,instructor, day,hour,min,time;
        public ViewHolder(View itemView) {
            super(itemView);
            default_image = (ImageView) itemView.findViewById(R.id.default_image);
            title = (TextView) itemView.findViewById(R.id.title);
            instructor =  (TextView) itemView.findViewById(R.id.instructor);
            day =  (TextView) itemView.findViewById(R.id.day);
            min =  (TextView) itemView.findViewById(R.id.min);
            hour =  (TextView) itemView.findViewById(R.id.hour);
            time =  (TextView) itemView.findViewById(R.id.time);

        }
    }
}
