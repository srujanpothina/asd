package com.example.sridh.course_register;


import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import io.realm.Realm;

import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class Add_instructor extends Fragment {

    String userName = "";
    Realm realm;
    int PERMISSION_REQUEST_LC_CODE = 99;

    public static final Integer REQUEST_CAMERA=1, SELECT_FILE=0;
    Bitmap img;
    Boolean gallery = false;
    String galluer_path = "";
    private OnFragmentInteractionListener mListener;
    private static final int SELECT_PICTURE = 100;

    private static int RESULT_LOAD_IMAGE = 1;
    String path = "";

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Add_instructor() {
        // Required empty public constructor
    }

    ImageView image1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_add_instructor,container, false);
        check_location_permission();
        image1=(ImageView)view.findViewById(R.id.addInstructorImage);

        image1.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Log.d("demo", "imageselected");
              final CharSequence[] items = {"Take Photo", "Choose from Gallery",
                      "Cancel"};
              AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
              builder.setTitle("Add Photo");
              builder.setItems(items, new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int item) {

                      if (items[item].equals("Take Photo")) {
                          Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                          startActivityForResult(cameraIntent, REQUEST_CAMERA);
                      } else if (items[item].equals("Choose from Gallery")) {
//                            Intent intent = new Intent();
//                            intent.setType("image/*");
//                            intent.setAction(Intent.ACTION_GET_CONTENT);//
//                            startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
                          if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                              Intent photoPickerIntent = new Intent(Intent.ACTION_GET_CONTENT);
                              photoPickerIntent.setType("image/*");
                              startActivityForResult(photoPickerIntent, SELECT_FILE);
                          } else {
                              Toast.makeText(getContext(),"Gallery permission was not granted",Toast.LENGTH_SHORT).show();
                          }

                      } else if (items[item].equals("Cancel")) {
                          dialog.dismiss();
                      }
                  }
              });
              builder.show();
          }
      });






        view.findViewById(R.id.resetInstructor).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                // set title
                alertDialogBuilder.setTitle("Reset");

                // set dialog message
                alertDialogBuilder
                        .setMessage("Are you sure ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                image1.setImageResource(R.drawable.add_photo);
                                EditText email=(EditText) getActivity().findViewById(R.id.email);
                                EditText website=(EditText) getActivity().findViewById(R.id.website);
                                EditText firstname=(EditText) getActivity().findViewById(R.id.firstname);
                                EditText lastname=(EditText) getActivity().findViewById(R.id.lastname);

                                email.setText("");
                                website.setText("");
                                firstname.setText("");
                                lastname.setText("");

                            }
                        })
                        .setNegativeButton("No",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {

                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
            }
        });

        view.findViewById(R.id.addRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button register=(Button)getActivity().findViewById(R.id.buttonRegister);
                EditText email=(EditText) getActivity().findViewById(R.id.email);
                EditText website=(EditText) getActivity().findViewById(R.id.website);
                EditText firstname=(EditText) getActivity().findViewById(R.id.firstname);
                EditText lastname=(EditText) getActivity().findViewById(R.id.lastname);

                if(email.getText().toString().trim().isEmpty()){
                    Toast.makeText(getActivity(),"Username cannot be empty",Toast.LENGTH_SHORT).show();
                } else if(website.getText().toString().trim().isEmpty()){
                    Toast.makeText(getActivity(),"Website cannot be empty",Toast.LENGTH_SHORT).show();
                } else if(firstname.getText().toString().trim().isEmpty()) {
                    Toast.makeText(getActivity(),"First name cannot be empty",Toast.LENGTH_SHORT).show();
                } else if(lastname.getText().toString().trim().isEmpty()) {
                    Toast.makeText(getActivity(),"Last name cannot be empty",Toast.LENGTH_SHORT).show();
                } else    {
                    String path = "";
                    if(gallery){
                        path = galluer_path;
                    } else {
                        if(img != null){
                            path=saveToInternalStorage(img,firstname.getText().toString().trim()+lastname.getText().toString().trim());
                            path = path + "/"+firstname.getText().toString().trim()+lastname.getText().toString().trim()+".jpg";
                        }
                    }
                    //String path=saveToInternalStorage(img,username.getText().toString());

                    Log.d("demo path",path);

                    realm.init(getActivity());
                    realm=realm.getDefaultInstance();
                    Instructors value = realm.where(Instructors.class).equalTo("instructor_firstname",firstname.getText().toString().trim())
                            .equalTo("instrctor_lastname",lastname.getText().toString().trim())
                            .equalTo("username3",userName)
                            .findFirst();
                    if(value != null) {
                        Toast.makeText(getActivity(),"Instructor Already exists",Toast.LENGTH_SHORT).show();
                    } else {
                        realm.beginTransaction();

                        Instructors instructors = realm.createObject(Instructors.class);
                        instructors.setUsername3(userName);
                        instructors.setInstructor_firstname(firstname.getText().toString().trim());
                        instructors.setInstrctor_lastname(lastname.getText().toString().trim());
                        instructors.setInstructor_image(path);
                        instructors.setInstructor_email(email.getText().toString().trim());
                        instructors.setInstructor_website(website.getText().toString().trim());
                        //userList.setUsername(usernameRegister.getText().toString().trim());
//                      //DB operations
                        realm.commitTransaction();
                        Log.d("demo",instructors.toString());
                        mListener.SaveInstructor();
                        // To image load
                        //loadImageFromStorage(path,username.getText().toString());

                    }
                }
            }
        });
        return view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Register.OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;

        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }


    private String saveToInternalStorage(Bitmap bitmapImage,String username){
        ContextWrapper cw = new ContextWrapper(getContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,username+".jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

    public void onResume(){
        super.onResume();

        // Set title bar
        ((MainActivity) getActivity())
                .setActionBarTitle("Add Instructor");

    }

    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().getApplicationContext().getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    public Boolean check_location_permission(){
        if(ContextCompat.checkSelfPermission(this.getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),Manifest.permission.READ_EXTERNAL_STORAGE)){
                ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST_LC_CODE);
            } else {
                ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST_LC_CODE);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode== RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                // Get the url from data
                gallery = true;
                String filepath = "";
                String wholeId = DocumentsContract.getDocumentId(data.getData());
                String id = wholeId.split(":")[1];
                String[] column = {MediaStore.Images.Media.DATA};
                String sel = MediaStore.Images.Media._ID + "=?";
                Cursor cursor = this.getContext().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,column,sel,new String[]{id},null);
                int columnIndex = cursor.getColumnIndex(column[0]);
                if(cursor.moveToFirst()){
                    filepath = cursor.getString(columnIndex);
                    galluer_path = filepath;
                }
                cursor.close();
                Log.d("path0",filepath);
                Uri uri = Uri.fromFile(new File(filepath));
                image1.setImageURI(uri);
//
//                Uri selectedImageUri = data.getData();
//                if (null != selectedImageUri) {
//                    // Get the path from the Uri
//                    path = getPathFromURI(selectedImageUri);
//                   Log.d("Image Path  ",  path);
//
//                    ImageView img1=getActivity().findViewById(R.id.image);
//
//                try {
//                    File f=new File(path,".jpg");
//                    Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
//
//
//                    img1.setImageBitmap(b);
//                }
//                catch (FileNotFoundException e)
//                {
//                    e.printStackTrace();
//                }
//
//
//                    // Set the image in ImageView
//
//                   // img1.setImageURI(selectedImageUri);
//                }
            }
            else if (requestCode == REQUEST_CAMERA) {
                img= (Bitmap) data.getExtras().get("data");
                image1.setImageBitmap(img);
                gallery = false;
            }
        }
    }


    public interface OnFragmentInteractionListener {
        void SaveInstructor();
    }


}
