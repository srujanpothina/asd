package com.example.sridh.course_register;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Instructors extends RealmObject {

    String instructor_email;
    String instructor_website,instructor_firstname,instrctor_lastname,username3,instructor_image;

    public String getUsername3() {
        return username3;
    }

    public void setUsername3(String username3) {
        this.username3 = username3;
    }

    public String getInstructor_image() {
        return instructor_image;
    }

    public void setInstructor_image(String instructor_image) {
        this.instructor_image = instructor_image;
    }
    public String getInstructor_email() {
        return instructor_email;
    }

    public void setInstructor_email(String instructor_email) {
        this.instructor_email = instructor_email;
    }

    public String getInstructor_website() {
        return instructor_website;
    }

    public void setInstructor_website(String instructor_website) {
        this.instructor_website = instructor_website;
    }

    public String getInstructor_firstname() {
        return instructor_firstname;
    }

    public void setInstructor_firstname(String instructor_firstname) {
        this.instructor_firstname = instructor_firstname;
    }

    public String getInstrctor_lastname() {
        return instrctor_lastname;
    }

    public void setInstrctor_lastname(String instrctor_lastname) {
        this.instrctor_lastname = instrctor_lastname;
    }

}
