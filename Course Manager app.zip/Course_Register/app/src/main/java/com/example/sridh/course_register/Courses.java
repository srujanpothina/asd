package com.example.sridh.course_register;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Courses extends RealmObject {
    String day,hour,min,morning_type,credit_hour,semster, instructor_firstname, instrctor_lastname,username2,instructor_Image;
    @PrimaryKey
    String courseTitle;

    public String getUsername2() {
        return username2;
    }

    public void setUsername2(String username2) {
        this.username2 = username2;
    }

    public String getInstructor_Image() {
        return instructor_Image;
    }

    public void setInstructor_Image(String instructor_Image) {
        this.instructor_Image = instructor_Image;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getMorning_type() {
        return morning_type;
    }

    public void setMorning_type(String morning_type) {
        this.morning_type = morning_type;
    }

    public String getCredit_hour() {
        return credit_hour;
    }

    public void setCredit_hour(String credit_hour) {
        this.credit_hour = credit_hour;
    }

    public String getSemster() {
        return semster;
    }

    public void setSemster(String semster) {
        this.semster = semster;
    }

    public String getInstructor_firstname() {
        return instructor_firstname;
    }

    public void setInstructor_firstname(String instructor_firstname) {
        this.instructor_firstname = instructor_firstname;
    }

    public String getInstrctor_lastname() {
        return instrctor_lastname;
    }

    public void setInstrctor_lastname(String instrctor_lastname) {
        this.instrctor_lastname = instrctor_lastname;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }
}
