package com.example.sridh.course_register;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import io.realm.Realm;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;

public class Register extends Fragment {
    Realm realm;
    ImageView image;
    public static final Integer REQUEST_CAMERA=1, SELECT_FILE=0;
    int PERMISSION_REQUEST_LC_CODE = 99;
    Bitmap img;
    Boolean gallery = false;
    String galluer_path = "";
    private OnFragmentInteractionListener mListener;
    private static final int SELECT_PICTURE = 100;

    private static int RESULT_LOAD_IMAGE = 1;
    String path = "";
    public Register() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        
        View view = inflater.inflate(R.layout.fragment_register,container, false);
        check_location_permission();
        image=(ImageView)view.findViewById(R.id.image);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final CharSequence[] items = { "Take Photo", "Choose from Gallery",
                        "Cancel" };
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Add Photo");
                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {

                        if (items[item].equals("Take Photo")) {
                            Intent cameraIntent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(cameraIntent,REQUEST_CAMERA);
                        } else if (items[item].equals("Choose from Gallery")) {


//                            Intent intent = new Intent();
//                            intent.setType("image/*");
//                            intent.setAction(Intent.ACTION_GET_CONTENT);//
//                            startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);


//                            Intent i = new Intent(
//                                    Intent.ACTION_PICK,
//                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//
//                            startActivityForResult(i, RESULT_LOAD_IMAGE);

//                            Intent intent = new Intent();
//                            intent.setType("image/*");
//                            intent.setAction(Intent.ACTION_GET_CONTENT);
//                            startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);

                            if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                                Intent photoPickerIntent = new Intent(Intent.ACTION_GET_CONTENT);
                                photoPickerIntent.setType("image/*");
                                startActivityForResult(photoPickerIntent, SELECT_FILE);
                            } else {
                                Toast.makeText(getContext(),"Gallery permission was not granted",Toast.LENGTH_SHORT).show();
                            }

                        } else if (items[item].equals("Cancel")) {
                            dialog.dismiss();
                        }
                    }
                });
                builder.show();


            }
        });
        view.findViewById(R.id.buttonRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button register=(Button)getActivity().findViewById(R.id.buttonRegister);
                EditText usernameRegister=(EditText) getActivity().findViewById(R.id.usernameRegister);
                EditText password=(EditText) getActivity().findViewById(R.id.passwordRegister);
                EditText firstname=(EditText) getActivity().findViewById(R.id.firstname);
                EditText lastname=(EditText) getActivity().findViewById(R.id.lastname);

                if(usernameRegister.getText().toString().trim().isEmpty()){
                    Toast.makeText(getActivity(),"Username cannot be empty",Toast.LENGTH_SHORT).show();
                } else if(password.getText().toString().length() < 8) {
                    Toast.makeText(getActivity(),"Password length is less than 8 characters",Toast.LENGTH_SHORT).show();
                } else if(firstname.getText().toString().trim().isEmpty()) {
                    Toast.makeText(getActivity(),"First name cannot be empty",Toast.LENGTH_SHORT).show();
                } else if(lastname.getText().toString().trim().isEmpty()) {
                    Toast.makeText(getActivity(),"Last name cannot be empty",Toast.LENGTH_SHORT).show();
                } else    {
                    if(gallery){
                        path = galluer_path;
                    } else {
                        if(img != null){
                            path=saveToInternalStorage(img,usernameRegister.getText().toString());
                            path = path + "/"+usernameRegister.getText().toString()+".jpg";
                        }
                    }
//                    if(img != null){
//                        path=saveToInternalStorage(img,usernameRegister.getText().toString());
//                        Log.d("pathCamera",path);
//                    }
                    //String path=saveToInternalStorage(img,username.getText().toString());

                    Log.d("demo path",path);

                    realm.init(getActivity());
                    realm=realm.getDefaultInstance();
                    UserList value = realm.where(UserList.class).equalTo("username",usernameRegister.getText().toString().trim()).findFirst();
                    if(value != null) {
                        Toast.makeText(getActivity(),"UserList name already exits. Please give a unique user name",Toast.LENGTH_SHORT).show();
                    } else {
                        realm.beginTransaction();

                        UserList userList = realm.createObject(UserList.class,usernameRegister.getText().toString().trim());
                        userList.setFirstname(firstname.getText().toString().trim());
                        userList.setLastname(lastname.getText().toString().trim());
                        userList.setImagepath(path);
                        userList.setPassword(password.getText().toString().trim());
                        //userList.setUsername(usernameRegister.getText().toString().trim());
//                      //DB operations
                        realm.commitTransaction();
                        mListener.SaveValues(Boolean.FALSE,Boolean.TRUE, usernameRegister.getText().toString().trim(),password.getText().toString().trim());
                        // To image load
                        //loadImageFromStorage(path,username.getText().toString());

                    }
                }
            }
        });
        return view;
    }
//    private void loadImageFromStorage(String path,String username)
//    {
//
//        try {
//            File f=new File(path, username+".jpg");
//            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
//
//            ImageView img=(ImageView)findViewById(R.id.display);
//            img.setImageBitmap(b);
//        }
//        catch (FileNotFoundException e)
//        {
//            e.printStackTrace();
//        }
//
//    }

    private String saveToInternalStorage(Bitmap bitmapImage,String username){
        ContextWrapper cw = new ContextWrapper(getContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,username+".jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;

        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public void onResume(){
        super.onResume();

        // Set title bar
        ((MainActivity) getActivity())
                .setActionBarTitle("Register");

    }

    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().getApplicationContext().getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    public Boolean check_location_permission(){
        if(ContextCompat.checkSelfPermission(this.getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),Manifest.permission.READ_EXTERNAL_STORAGE)){
                ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST_LC_CODE);
            } else {
                ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST_LC_CODE);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode== RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                // Get the url from data
                gallery = true;
                String filepath = "";
                String wholeId = DocumentsContract.getDocumentId(data.getData());
                String id = wholeId.split(":")[1];
                String[] column = {MediaStore.Images.Media.DATA};
                String sel = MediaStore.Images.Media._ID + "=?";
                Cursor cursor = this.getContext().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,column,sel,new String[]{id},null);
                int columnIndex = cursor.getColumnIndex(column[0]);
                if(cursor.moveToFirst()){
                    filepath = cursor.getString(columnIndex);
                    galluer_path = filepath;
                }
                cursor.close();
                Log.d("path0",filepath);
                Uri uri = Uri.fromFile(new File(filepath));
                image.setImageURI(uri);
            }
            else if (requestCode == REQUEST_CAMERA) {
                img= (Bitmap) data.getExtras().get("data");
                image.setImageBitmap(img);
                gallery = false;
            }
        }
    }

    public interface OnFragmentInteractionListener {
        void SaveValues(Boolean signUp,Boolean successfullLogin,String userName, String Passsword);
    }

}
